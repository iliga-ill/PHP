<?php

$host = 'web.ws.local'; // адрес сервера 
$database = 'web121'; // имя базы данных
$user = 'Web12'; // имя пользователя
$password = '9eTEJ1E6'; // пароль

?>