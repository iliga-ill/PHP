<?php
require_once 'connection.php'; // подключаем скрипт
 
// подключаемся к серверу
// function test() {

    $link = mysqli_connect($host, $user, $password, $database) 
        or die("Ошибка " . mysqli_error($link));
     
    // выполняем операции с базой данных
    $query ="SELECT * FROM users";
    $result = mysqli_query($link, $query) or die("Ошибка " . mysqli_error($link)); 
    if($result)
    {
        echo '<script>';
        echo 'console.log('. json_encode( $result ) .')';
        echo '</script>';
        // echo "Выполнение запроса прошло успешно";
    }
    
    // закрываем подключение
    mysqli_close($link);
// }

// test();

echo '<h1>I am smb</h1>';
?>
<button>1111</button>