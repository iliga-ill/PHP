

// function test(){
//     window.location.href = "http://localhost/view.php?
//                           width=" + width +
//                          "&height=" + height +
//                          "&color=" + colorDepth;
// } else exit();
// }